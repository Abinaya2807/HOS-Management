import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dispense',
  standalone: true,
  imports: [
    CommonModule
],
  templateUrl: './dispense.component.html',
  styleUrl: './dispense.component.css'
})
export class DispenseComponent {
  constructor(private router:Router){}
  gotohome(){
    this.router.navigate(['']);
  }

}
