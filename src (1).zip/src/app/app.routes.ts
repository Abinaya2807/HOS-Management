import { Routes } from '@angular/router';
import { RouterModule} from '@angular/router';
import { CommonComponent } from './common/common.component';
import { ProfileComponent } from './profile/profile.component';
import { NgModule } from '@angular/core';
import { profile } from 'console';
import { MedicineComponent } from './medicine/medicine.component';
import { InventoryListComponent } from './inventory-list/inventory-list.component';
import { DispenseComponent } from './dispense/dispense.component';
import { OrderMedicineComponent } from './order-medicine/order-medicine.component';
import { LogOutComponent } from './log-out/log-out.component';

export const routes: Routes = [
    
    {path:'',component:CommonComponent},
    {path:'profile',component:ProfileComponent},
    {path:'medicine',component:MedicineComponent},
    {path:'inventory',component:InventoryListComponent},
    {path:'dispense',component:DispenseComponent},
    {path:'order',component:OrderMedicineComponent},
    {path:'logout',component:LogOutComponent}

];

imports: [
    RouterModule.forRoot(routes)
]

