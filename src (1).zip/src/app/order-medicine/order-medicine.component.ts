import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { Router } from '@angular/router';
import { NgModel } from '@angular/forms';
import { FormsModule } from '@angular/forms';
@Component({
  selector: 'app-order-medicine',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './order-medicine.component.html',
  styleUrl: './order-medicine.component.css'
})
export class OrderMedicineComponent {
  constructor(private router:Router){};
  selectedSupplier: number= 1;
  suppliers=[
    {id: 1, name: 'Supplier 1'},
    {id: 1, name: 'Supplier 2'},
    {id: 1, name: 'Supplier 3'},
    {id: 1, name: 'Supplier 4'},
  ];
  gotohome(){
    this.router.navigate(['']);
  }
}
