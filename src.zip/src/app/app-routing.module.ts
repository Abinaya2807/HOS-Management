import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PatientComponent } from './patient/patient.component';
import { HomeComponent } from './home/home.component';
import { PhysicianComponent } from './physician/physician.component';

const routes: Routes = [{ path: '', redirectTo: '/Home',pathMatch:'full'},
                        { path: 'patient', component: PatientComponent },
                        { path: 'Home', component: HomeComponent },
                        { path: 'physician', component: PhysicianComponent} 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
