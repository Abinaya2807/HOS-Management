import { Component } from '@angular/core';

@Component({
  selector: 'app-physician',
  
  templateUrl: './physician.component.html',
  styleUrl: './physician.component.css'
})
export class PhysicianComponent {
  selectedOption: string | null = null; 
  prescriptionRows: string[][] = []; 
  profile: any = {};
  constructor() {
    
    this.prescriptionRows = [
      [' A', ' A', ' A', 'Instructions A'],
      [' B', ' B', ' B', 'Instructions B'],
      [' C', ' C', ' C', 'Instructions C']
    ];
  }

}
