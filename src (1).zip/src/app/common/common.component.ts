import { Component } from '@angular/core';
import { ProfileComponent } from '../profile/profile.component';
import { MedicineComponent } from '../medicine/medicine.component';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { InventoryListComponent } from '../inventory-list/inventory-list.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-common',
  standalone: true,
  imports: [ProfileComponent,MedicineComponent,InventoryListComponent,CommonModule],
  templateUrl: './common.component.html',
  styleUrl: './common.component.css'
})
export class CommonComponent {
  selectedContent: number = 0;
  constructor(private router:Router){};

  showContent(contentNumber: number){
    this.selectedContent = contentNumber;
  }

  gotoLogout(){
    this.router.navigate(['logout']);
  }
}
