import { Component } from '@angular/core';

@Component({
  selector: 'app-patient',
  templateUrl: './patient.component.html',
  styleUrls: ['./patient.component.css']
})
export class PatientComponent {
  selectedOption: string | null = null; 
  prescriptionRows: string[][] = []; 
  profile: any = {};
  constructor() {
    
    this.prescriptionRows = [
      [' A', ' A', ' A', 'Instructions A'],
      [' B', ' B', ' B', 'Instructions B'],
      [' C', ' C', ' C', 'Instructions C'],
      
    ];
  }
}
